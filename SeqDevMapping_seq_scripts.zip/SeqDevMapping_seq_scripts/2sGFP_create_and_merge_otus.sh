#!/bin/bash

otu_path=$1
unique_seqs_fn=$2
zotus_fn=$3
output_otu_fn=$4
unique_path=$5

# denoise unique reads and create the zotus file, default minsize = 8 (to change: -minsize 12)
usearch -unoise3 $unique_seqs_fn -zotus $zotus_fn

# Create the OTU tables
for idx in {1..12..1}; do
	usearch -otutab $unique_path"Aby_RPI_"$idx"_unique.fq" -zotus $zotus_fn -otutabout $otu_path"Aby_RPI_"$idx"_otutable.txt" -threads 10
done

# Merge OTU tables
usearch -otutab_merge $otu_path"Aby_RPI_1_otutable.txt,"\
$otu_path"Aby_RPI_2_otutable.txt,"\
$otu_path"Aby_RPI_3_otutable.txt,"\
$otu_path"Aby_RPI_4_otutable.txt,"\
$otu_path"Aby_RPI_5_otutable.txt,"\
$otu_path"Aby_RPI_6_otutable.txt,"\
$otu_path"Aby_RPI_7_otutable.txt,"\
$otu_path"Aby_RPI_8_otutable.txt,"\
$otu_path"Aby_RPI_9_otutable.txt,"\
$otu_path"Aby_RPI_10_otutable.txt,"\
$otu_path"Aby_RPI_11_otutable.txt,"\
$otu_path"Aby_RPI_12_otutable.txt"\
 -output $output_otu_fn
