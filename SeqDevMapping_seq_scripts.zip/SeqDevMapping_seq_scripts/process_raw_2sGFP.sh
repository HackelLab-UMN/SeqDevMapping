#!/bin/bash:

raw_path=$1
merged_path=$2
aligned_path=$3
filtered_path=$4
unique_path=$5

# Merge, align, and filter reads into unique sequences for FB1
# Affibody
sample=1
for idx in {1..12..1}
do
	usearch -fastq_mergepairs $raw_path"RPI"$idx"_S"$sample"_L001_R1_001.fastq" -fastqout $merged_path"Aby_RPI_"$idx"_merged.fq" -relabel @
	
	usearch -search_pcr2 $merged_path"Aby_RPI_"$idx"_merged.fq" -fwdprimer AAGGAGATATACATATGGCTAGC -revprimer CCTCCACCGGATCC -strand plus -fastqout $aligned_path"Aby_RPI_"$idx"_aligned.fq"
	
	usearch -fastq_filter $aligned_path"Aby_RPI_"$idx"_aligned.fq" -fastqout $filtered_path"Aby_RPI_"$idx"_filtered.fq" -fastq_maxee 1 -fastq_maxns 0
	
	usearch -fastx_uniques $filtered_path"Aby_RPI_"$idx"_filtered.fq" -fastqout $unique_path"Aby_RPI_"$idx"_unique.fq" -sizeout
	sample=$(($sample+1))
done

# Fibronectin
sample=13
for idx in {13..24..1}
do
        usearch -fastq_mergepairs $raw_path"RPI"$idx"_S"$sample"_L001_R1_001.fastq" -fastqout $merged_path"Fn_RPI_"$idx"_merged.fq" -relabel @

        usearch -search_pcr2 $merged_path"Fn_RPI_"$idx"_merged.fq" -fwdprimer AACTCTCTGACTATTTCT -revprimer GCGATAATTGATGCTGAT -strand plus -fastqout $aligned_path"Fn_RPI_"$idx"_aligned.fq"

        usearch -fastq_filter $aligned_path"Fn_RPI_"$idx"_aligned.fq" -fastqout $filtered_path"Fn_RPI_"$idx"_filtered.fq" -fastq_maxee 1 -fastq_maxns 0

        usearch -fastx_uniques $filtered_path"Fn_RPI_"$idx"_filtered.fq" -fastqout $unique_path"Fn_RPI_"$idx"_unique.fq" -sizeout
        sample=$(($sample+1))
done

# merge filtered reads
cat $filtered_path"Aby_RPI_"*"_filtered.fq" > $filtered_path"aby_filtered_seqs.fq"
cat $filtered_path"Fn_RPI_"*"_filtered.fq" > $filtered_path"fn_filtered_seqs.fq"

# find uniques of merged population
usearch -fastx_uniques $filtered_path"aby_filtered_seqs.fq" -fastaout $unique_path"aby_unique_seqs.fq" -sizeout
usearch -fastx_uniques $filtered_path"fn_filtered_seqs.fq" -fastaout $unique_path"fn_unique_seqs.fq" -sizeout
##########################################################################################################################################################

